const inputName = document.getElementById('name');
const emailName = document.getElementById('email');
const siteName = document.getElementById('site');
const mainList = document.getElementById('main');
// console.log(inputName);
document.addEventListener('DOMContentLoaded', ()=>{

   
    if(inputName != null){
        mainList.classList.add('alignMain');
    }
    
    function outputsize() {
        inputName.value = inputName.offsetWidth;
       }
       outputsize();
       
       new ResizeObserver(outputsize).observe(emailName);

})
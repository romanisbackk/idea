console.log('app');

"use strict"
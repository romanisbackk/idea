console.log('file 2');

const kitchens = document.querySelector(".kitchens");
const stools = document.querySelector(".stools");
const sofas = document.querySelector(".sofas");

// let styleKitchens = getComputedStyle(kitchens);
// let widthKitchens = parseInt(styleKitchens.width);

// let styleStools = getComputedStyle(stools);
// let widthStools = parseInt(styleStools.width);

// let styleSofas = getComputedStyle(sofas);
// let widthSofas = parseInt(styleSofas.width);
if(kitchens != null){
    kitchens.addEventListener('mouseenter', ()=>{
        kitchens.style.width = "600px"
        stools.style.width = "200px"
        sofas.style.width = "510px"
    })
    
    kitchens.addEventListener('mouseleave', ()=>{
        kitchens.style.width = "555px"
        stools.style.width = "200px"
        sofas.style.width = "555px"
    })
    
    stools.addEventListener('mouseenter', ()=>{
        stools.style.width = "250px"
        kitchens.style.width = "530px"
        sofas.style.width = "530px"
    })
    
    stools.addEventListener('mouseleave', ()=>{
        stools.style.width = "200px"
        kitchens.style.width = "555px"
        sofas.style.width = "555px"
    })
    
    sofas.addEventListener('mouseenter', ()=>{
        sofas.style.width = "600px"
        kitchens.style.width = "510px"
        stools.style.width = "200px"
    })
    
    sofas.addEventListener('mouseleave', ()=>{
        kitchens.style.width = "555px"
        stools.style.width = "200px"
        sofas.style.width = "555px"
    })
}

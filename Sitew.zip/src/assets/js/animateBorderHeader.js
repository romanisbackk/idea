let any = document.querySelectorAll(".link");
console.log(any);

// function joe () {
//    any.forEach(elem => {
//     elem.addEventListener('mouseenter', ()=>{
//             elem.style.borderBottom = "3px solid black";
//     })
//     });

//     any.forEach(elem => {
//         elem.addEventListener('mouseleave', ()=>{
//             elem.style.borderBottom = "none";
//         })
//         });
// }

// joe();


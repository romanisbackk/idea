const constantCatalog = document.querySelector(".first");
const allHover = document.getElementsByTagName('a');
const getLi = document.getElementsByTagName('li');
const pictureBody = document.body;
// allHover[0].classList.add('visited');

document.addEventListener("DOMContentLoaded", ()=>{

    if(constantCatalog != null){
        pictureBody.classList.add('PictureOne');
        constantCatalog.classList.add('isActive')
    

     
       
        function checkIndex() {
            allHover[6].addEventListener('mouseenter', ()=>{
                pictureBody.classList.add('PictureTwo');
                allHover[6].classList.add('isActive')
                constantCatalog.classList.remove('isActive');
                pictureBody.classList.remove('PictureOne');
                pictureBody.classList.remove('PictureThree');
                pictureBody.classList.remove('PictureFore');
                allHover[7].classList.remove('isActive');
                allHover[8].classList.remove('isActive');
            })
            allHover[7].addEventListener('mouseenter', ()=>{
                pictureBody.classList.add('PictureThree');
                allHover[7].classList.add('isActive');
                constantCatalog.classList.remove('isActive');
                pictureBody.classList.remove('PictureOne');
                pictureBody.classList.remove('PictureTwo');
                pictureBody.classList.remove('PictureFore');
                allHover[6].classList.remove('isActive');
                allHover[8].classList.remove('isActive');
            })
            allHover[8].addEventListener('mouseenter', ()=>{
                pictureBody.classList.add('PictureFore');
                allHover[8].classList.add('isActive');
                constantCatalog.classList.remove('isActive');
                pictureBody.classList.remove('PictureOne');
                pictureBody.classList.remove('PictureTwo');
                pictureBody.classList.remove('PictureThree');
                allHover[6].classList.remove('isActive');
                allHover[7].classList.remove('isActive');
            })
         
        constantCatalog.addEventListener('mouseenter', ()=>{
            constantCatalog.classList.add('isActive');
            pictureBody.classList.add('PictureOne');
            pictureBody.classList.remove('PictureTwo');
            pictureBody.classList.remove('PictureThree');
            pictureBody.classList.remove('PictureFore');
            allHover[6].classList.remove('isActive');
            allHover[7].classList.remove('isActive');
            allHover[8].classList.remove('isActive');
        })
        
        }
        checkIndex();
    }
   
})
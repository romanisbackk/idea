console.log('file 3');

const partners = document.querySelector(".partners");
const textHello = document.querySelector(".text-hello");
const services = document.querySelector(".services");

// let partners = getComputedStyle(kitchens);
// let widthKitchens = parseInt(styleKitchens.width);

// let styleStools = getComputedStyle(stools);
// let widthStools = parseInt(styleStools.width);

// let styleSofas = getComputedStyle(sofas);
// let widthSofas = parseInt(styleSofas.width);

if(partners != null){
    partners.addEventListener('mouseenter', ()=>{
        partners.style.width = "380px";
        textHello.style.width = "470px";
        services.style.width = "500px";
    })
    
    partners.addEventListener('mouseleave', ()=>{
        partners.style.width = "324px";
        textHello.style.width = "435px";
        services.style.width = "550px";
    })
    
    services.addEventListener('mouseenter', ()=>{
        services.style.width = "600px";
        partners.style.width = "321px";
        textHello.style.width = "447px";
    })
    
    services.addEventListener('mouseleave', ()=>{
        partners.style.width = "324px";
        textHello.style.width = "435px";
        services.style.width = "550px";
    })
}




